<?php
    	$banner = App\Models\Banner::where('page' , $page)->first();
?>
<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-5">
                <div class="intro-excerpt">
                    <h1><?php echo $banner->title; ?></h1>
                    <p class="mb-4"><?php echo e($banner->description); ?></p>
                    <p><a href="" class="btn btn-secondary me-2">Shop Now</a><a href="#" class="btn btn-white-outline">Explore</a></p>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="hero-img-wrap">
                    <img src="<?php echo e(asset($banner->banner_img)); ?>" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\supercare-hospital\resources\views/frontend/include/hero.blade.php ENDPATH**/ ?>