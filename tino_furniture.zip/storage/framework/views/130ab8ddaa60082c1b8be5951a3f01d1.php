<?php $__env->startSection('body-content'); ?>
<!-- Start Hero Section -->
<?php echo $__env->make('frontend.include.hero' , ['page' => 'service'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Hero Section -->

		

		<!-- Start Why Choose Us Section -->
		<div class="why-choose-section">
			<div class="container">
				
				
				<div class="row my-5">
					<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>						
						<div class="col-6 col-md-6 col-lg-3 mb-4">
							<div class="feature">
								<div class="icon">
									<img src="<?php echo e(asset($department->image)); ?>" alt="Image" class="imf-fluid">
								</div>
								<h3><?php echo e($department->title); ?></h3>
								<p><?php echo e($department->description); ?></p>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			
			</div>
		</div>
		<!-- End Why Choose Us Section -->

		<!-- Start Product Section -->		
		<?php echo $__env->make('frontend.include.material', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- End Product Section -->

		

		<!-- Start Testimonial Slider -->
		<?php echo $__env->make('frontend.include.testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- End Testimonial Slider -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supercare-hospital\resources\views/frontend/pages/services.blade.php ENDPATH**/ ?>