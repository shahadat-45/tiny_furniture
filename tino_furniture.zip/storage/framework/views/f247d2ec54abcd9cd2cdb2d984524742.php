	
	<?php $__env->startSection('body-content'); ?>
	<!-- Start Hero Section -->		 
	
	<?php echo $__env->make('frontend.include.hero' , ['page' => 'home'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- End Hero Section -->

	<!-- Start Product Section -->
	<?php echo $__env->make('frontend.include.material', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- End Product Section -->

	<!-- Start Why Choose Us Section -->
	<?php echo $__env->make('frontend.include.why-choose', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- End Why Choose Us Section -->

	<!-- Start We Help Section -->
	<div class="we-help-section">
		<div class="container">
			<div class="row justify-content-between">
				<div class="col-lg-7 mb-5 mb-lg-0">
					<div class="imgs-grid">
						<?php
							$images = json_decode($headding->find(3)->image, true);
						?>
						<?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="grid grid-<?php echo e($i + 1); ?>"><img src="<?php echo e(asset($image ?? '')); ?>" alt="Untree.co"></div>
							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							
						<?php endif; ?>
					</div>
				</div>
				<div class="col-lg-5 ps-lg-5">
					<h2 class="section-title mb-4"><?php echo e($headding->find(3)->title ?? ''); ?></h2>
					<p><?php echo e($headding->find(3)->description ?? ''); ?></p>

					<ul class="list-unstyled custom-list my-4 d-flex flex-wrap">
						<?php $__currentLoopData = $interiors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interior): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($interior->text); ?></li>							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
					<p><a herf="#" class="btn">Explore</a></p>
				</div>
			</div>
		</div>
	</div>
	<!-- End We Help Section -->

	<!-- Start Popular Product -->
	<div class="popular-product">
		<div class="container">
			<div class="row">
				<?php $__currentLoopData = $furnitures->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furniture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-12 col-md-6 col-lg-4 mb-4 mb-lg-0">
						<div class="product-item-sm d-flex">
							<div class="thumbnail">
								<img src="<?php echo e(asset($furniture->image)); ?>" alt="Image" class="img-fluid">
							</div>
							<div class="pt-3">
								<h3><?php echo e($furniture->title); ?></h3>
								<p><?php echo e($furniture->description); ?></p>
								<p><a href="<?php echo e($furniture->link); ?>">Read More</a></p>
							</div>
						</div>
					</div>					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
	<!-- End Popular Product -->

	<!-- Start Testimonial Slider -->
	<?php echo $__env->make('frontend.include.testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
	<!-- End Testimonial Slider -->

	<!-- Start Blog Section -->
	<div class="blog-section">
		<div class="container">
			<div class="row mb-5">
				<div class="col-md-6">
					<h2 class="section-title">Recent Blog</h2>
				</div>
				<div class="col-md-6 text-start text-md-end">
					<a href="<?php echo e(route('blog')); ?>" class="more">View All Posts</a>
				</div>
			</div>
			<div class="row">
				<?php $__currentLoopData = $blogs->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-12 col-sm-6 col-md-4 mb-4 mb-md-0">
						<div class="post-entry">
							<a href="<?php echo e(route('blogDetail' , $blog->id)); ?>" class="post-thumbnail"><img src="<?php echo e(asset($blog->blog_image)); ?>" alt="Image" class="img-fluid"></a>
							<div class="post-content-entry">
								<h3><a href="<?php echo e(route('blogDetail' , $blog->id)); ?>"><?php echo e($blog->blog_title); ?></a></h3>
								<div class="meta">
									<span>by <a href="<?php echo e(route('blogDetail' , $blog->id)); ?>"><?php echo e($blog->blog_author); ?></a></span> <span>on <a href="#"><?php echo e($blog->blog_date); ?></a></span>
								</div>
							</div>
						</div>
					</div>					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
	<!-- End Blog Section -->		
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supercare-hospital\resources\views/frontend/pages/index.blade.php ENDPATH**/ ?>