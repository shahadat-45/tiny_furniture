<div class="product-section">
    <div class="container">
        <div class="row">

            <!-- Start Column 1 -->
            <div class="col-md-12 col-lg-3 mb-5 mb-lg-0">
                <h2 class="mb-4 section-title"><?php echo e($headding->find(1)->title ?? ''); ?></h2>
                <p class="mb-4"><?php echo e($headding->find(1)->description ?? ''); ?></p>
                <p><a href="<?php echo e(route('shop')); ?>" class="btn">Explore</a></p>
            </div>

            <!-- Start Column -->
            <?php $__currentLoopData = $material->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
                    <a class="product-item">
                        <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid product-thumbnail">
                        <h3 class="product-title"><?php echo e($item->title); ?></h3>

                        <span class="icon-cross">
                            <img src="<?php echo e(asset('public/frontend/images/cross.svg')); ?>" class="img-fluid">
                        </span>
                    </a>
                </div>
                <!-- End Column -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\supercare-hospital\resources\views/frontend/include/material.blade.php ENDPATH**/ ?>