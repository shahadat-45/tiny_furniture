<?php $__env->startSection('body-content'); ?>
<!-- Start Hero Section -->
<?php echo $__env->make('frontend.include.hero' , ['page' => 'blog'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Hero Section -->



<!-- Start Blog Section -->
<div class="blog-section">
	<div class="container">
		
		<div class="row">
			<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-12 col-sm-6 col-md-4 mb-5">
					<div class="post-entry">
						<a href="<?php echo e(route('blogDetail' , $blog->id)); ?>" class="post-thumbnail"><img src="<?php echo e(asset($blog->blog_image)); ?>" alt="Image" class="img-fluid"></a>
						<div class="post-content-entry">
							<h3><a href="<?php echo e(route('blogDetail' , $blog->id)); ?>"><?php echo e($blog->blog_title); ?></a></h3>
							<div class="meta">
								<span>by <a href="<?php echo e(route('blogDetail' , $blog->id)); ?>"><?php echo e($blog->blog_author); ?></a></span> <span>on <a href="#"><?php echo e($blog->blog_date); ?></a></span>
							</div>
						</div>
					</div>
				</div>				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>
<!-- End Blog Section -->	



<!-- Start Testimonial Slider -->
<?php echo $__env->make('frontend.include.testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Testimonial Slider -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supercare-hospital\resources\views/frontend/pages/blog.blade.php ENDPATH**/ ?>