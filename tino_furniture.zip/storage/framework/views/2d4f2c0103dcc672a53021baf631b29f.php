<div class="why-choose-section">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-6">
                <h2 class="section-title"><?php echo e($headding->find(2)->title ?? ''); ?></h2>
                <p><?php echo e($headding->find(2)->description ?? ''); ?></p>

                <div class="row my-5">
                    <?php $__currentLoopData = $departments->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6 col-md-6">
                            <div class="feature">
                                <div class="icon">
                                    <img src="<?php echo e(asset($department->image ?? '')); ?>" alt="Image" class="imf-fluid">
                                </div>
                                <h3><?php echo e($department->title ?? ''); ?></h3>
                                <p><?php echo e($department->description ?? ''); ?></p>
                            </div>
                        </div>							
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="img-wrap">
                    <img src="<?php echo e(asset($headding->find(2)->image ?? '')); ?>" alt="Image" class="img-fluid">
                </div>
            </div>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\supercare-hospital\resources\views/frontend/include/why-choose.blade.php ENDPATH**/ ?>