<!DOCTYPE html>
<html lang="en">
<?php $setting = App\Models\BasicInfo::find(1); ?>
<head>
     <?php echo $__env->make('frontend.include.head-titles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php echo $__env->yieldContent('style'); ?>    
</head>

<body>
   <?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Body container start -->

            <?php echo $__env->yieldContent('body-content'); ?>

        <!-- Body container end -->

    <!-- Footer section start -->
         <?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer section end -->


     <?php echo $__env->make('frontend.include.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>


<?php /**PATH C:\xampp\htdocs\supercare-hospital\resources\views/frontend/layout/master.blade.php ENDPATH**/ ?>